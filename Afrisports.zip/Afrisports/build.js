$(document).ready(function{} {
    $.ajax({
        url:"http://www.africanports.com",
        success:function (data) {
            $('main-headline-img1').attr("src", data.artices[0].urlToImage);
            $('main-headline-title1').attr("src", data.artices[0].title);
            $('main-headline-source1').attr("src", data.artices[0].source.name);
            
            const date = new date();
            date.setDate(fata.articles[0].publishedAt);

        },
        error:function () {
            alert("Some Error Occured");

        }
    });

    
    $.ajax({
        url:"https://newsapi.org/v2/everything?q=sports&apiKey=15cbe3f5e854f8ebf1858c526a52932",
        success:function (data) {
            for(let i=0;i<=4;i++){
                $('#corona-News').append('

            <div class="col-md-8">
                <div class="card">
                    <img id="main-headline-img1" class="card-img-top" scr="https://wallpapercave.com/wp/wp2458583.jpg" alt="card img cap">
                    <div class="card-body">
                        <h3 id="main-headline-title1" class="card-title">News Item</h3>
                        <h5 id="main-headline-source1" class="text-info">Sports Insider</h5>
                        <a href="#" class="btn btn-primary btn-block">60</a>
                    </div>
                </div>
            </div>
                                        ')

            }       
        },

        
        error:function () {
            alert("Error");

        }
    });

            

})

/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  
  // Close the dropdown menu if the user clicks outside of it
  window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }